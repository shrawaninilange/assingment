const mongoose =require("mongoose")

const userSchema= new mongoose.Schema({
    id : {type :Number, required: false},
    first_name : String,
    last_name : String,
    email : String,
    gender : String,
    password : String,
    ip_address : String,
})


const User = mongoose.model("user", userSchema)

module.exports=User