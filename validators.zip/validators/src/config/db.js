const mongoose = require("mongoose")

const connect= () => {
    //mongodb url
 return mongoose.connect("mongodb://localhost:27017/users")
}

module.exports=connect