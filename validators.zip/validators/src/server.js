const express  = require("express")
const connect = require("./config/db")
const app = express()

 
const userControllers  =  require("./controllers/user.controllers")
app.use(express.json()) 
app.use("/users ",userControllers)

const start =async () =>{
     try {
      await connect()
     } catch (error) {
       console.log(error)
     }
    app.listen(2000, ()=>{
      console.log("lis")
    })
}
module.exports=start