const express =require("express")
const router = express.Router()

const User= require("../models/user.model")

router.get("/" ,async (req ,res )=>{
     
    try {

        const userData  = await User.find({}).lean().exec()
    
        return res.send(userData)
           
       } catch (error) {
           return res
           .status(200)
           .send({message :"somethig" })
       }
 
})


router.post("/" ,
       async (req ,res )=>{
     
        try {
     
         const users   = await User.create(req.body)
     
         return res.status(201).send(users);
        } catch (error) {
            return res
            .status(200)
            .send({message :"somethig" })
        }
     
})


router.get("//:id", async (req, res) => {
    try {
      const user = await User.findById(req.params.id).lean().exec();
      // db.users.findOne({_id: Object('622893471b0065f917d24a38')})
  
      return res.status(200).send(user);
    } catch (err) {
      return res.status(500).send({ message: err.message });
    }
  });
  

module.exports= router